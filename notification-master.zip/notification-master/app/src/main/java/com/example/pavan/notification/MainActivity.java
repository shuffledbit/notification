package com.example.pavan.notification;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button btn;
EditText edit1,edit2,edit3,edit4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.btn);
        edit1=findViewById(R.id.ed1);

        edit2=findViewById(R.id.ed2);
        edit3=findViewById(R.id.ed3);
        edit4=findViewById(R.id.ed4);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://"+edit1.getText().toString();
                String text=edit2.getText().toString();
                String content_text=edit3.getText().toString();
                String sub_text=edit4.getText().toString();

                if(url.equals("") || text.equals("") || content_text.equals("") || sub_text.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "fields should not be empty", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(),"random_id");

                    builder.setSmallIcon(R.drawable.ic_launcher_background);
                    builder.setContentIntent(pendingIntent);
                    builder.setAutoCancel(true);

                    builder.setSmallIcon(R.drawable.notification);
                    builder.setContentTitle(text);
                    builder.setContentText(content_text);
                    builder.setSubText(sub_text);

                    NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    notificationManager.notify(0, builder.build());
                }

            }
        });



    }
}
